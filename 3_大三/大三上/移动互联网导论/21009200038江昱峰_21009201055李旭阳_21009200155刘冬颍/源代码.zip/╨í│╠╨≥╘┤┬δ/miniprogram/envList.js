const envList = [{"envId": "cloud1-6grlmnp6a2096931", "alias": "cloud1"}]
const isMac = false
module.exports = {
  envList,
  isMac
}
